[jQuery Treeview Plugin](http://bassistance.de/jquery-plugins/jquery-plugin-treeview/) - Its just a tree
================================

Converts nested lists into a mouse-navigatable tree - not keyboard support, yet.

Provides some options for customizing, an async-tree extension and an experimental sortable extension.

API documentation can be found at [http://docs.jquery.com/Plugins/Treeview](http://docs.jquery.com/Plugins/Treeview). There's also some background on the async extension.
