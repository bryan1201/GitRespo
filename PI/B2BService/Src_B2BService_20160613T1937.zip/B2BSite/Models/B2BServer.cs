﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
namespace B2BSite.Models
{
    public class B2BServer
    {
    }

    public class PIDServerRawData: IRawData
    {
        public RawData Get()
        {
            RawData r = new RawData();
            return r;
        }

        public RawData Get(string messageid, string contenttype)
        {
            string url = Constant.PIDUrl;
            RawData r = new RawData(messageid, url, contenttype);
            return r;
        }
    }

    public class PIQServerRawData : IRawData
    {
        public RawData Get()
        {
            RawData r = new RawData();
            return r;
        }

        public RawData Get(string messageid, string contenttype)
        {
            string url = Constant.PIQUrl;
            RawData r = new RawData(messageid, url, contenttype);
            return r;
        }
    }

    public class PIPServerRawData : IRawData
    {
        public RawData Get()
        {
            RawData r = new RawData();
            return r;
        }

        public RawData Get(string messageid, string contenttype)
        {
            string url = Constant.PIPUrl;
            RawData r = new RawData(messageid, url, contenttype);
            return r;
        }
    }

    public class PIDServerMDN : IMDN
    {
        public MDN Get()
        {
            MDN r = new MDN();
            return r;
        }

        public MDN Get(string messageid, string contenttype)
        {
            string url = Constant.PIDUrl;
            MDN r = new MDN(messageid, url, contenttype);
            return r;
        }
    }

    public class PIQServerMDN : IMDN
    {
        public MDN Get()
        {
            MDN r = new MDN();
            return r;
        }

        public MDN Get(string messageid, string contenttype)
        {
            string url = Constant.PIQUrl;
            MDN r = new MDN(messageid, url, contenttype);
            return r;
        }
    }


    public class PIPServerMDN : IMDN
    {
        public MDN Get()
        {
            MDN r = new MDN();
            return r;
        }

        public MDN Get(string messageid, string contenttype)
        {
            string url = Constant.PIPUrl;
            MDN r = new MDN(messageid, url, contenttype);
            return r;
        }
    }

    public class PIDServerAuditLog : IAuditLog
    {
        public AuditLog Get()
        {
            AuditLog r = new AuditLog();
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog)JsonConvert.DeserializeObject<AuditLog>(jdo.ToString());
            return r;
        }

        public AuditLog Get(string messageid, string contenttype)
        {
            string url = Constant.PIDUrl;
            AuditLog r = new AuditLog(messageid, url, contenttype);
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog)JsonConvert.DeserializeObject<AuditLog>(jdo.ToString());
            return r;
        }

        public AuditLog2 Get2()
        {
            AuditLog2 r = new AuditLog2();
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog2)JsonConvert.DeserializeObject<AuditLog2>(jdo.ToString());
            return r;
        }

        public AuditLog2 Get2(string messageid, string contenttype)
        {
            string url = Constant.PIDUrl;
            AuditLog2 r = new AuditLog2(messageid, url, contenttype);
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog2)JsonConvert.DeserializeObject<AuditLog2>(jdo.ToString());
            return r;
        }
    }

    public class PIQServerAuditLog : IAuditLog
    {
        public AuditLog Get()
        {
            AuditLog r = new AuditLog();
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog)JsonConvert.DeserializeObject<AuditLog>(jdo.ToString());
            return r;
        }

        public AuditLog Get(string messageid, string contenttype)
        {
            string url = Constant.PIQUrl;
            AuditLog r = new AuditLog(messageid, url, contenttype);
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog)JsonConvert.DeserializeObject<AuditLog>(jdo.ToString());
            return r;
        }

        public AuditLog2 Get2()
        {
            AuditLog2 r = new AuditLog2();
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog2)JsonConvert.DeserializeObject<AuditLog2>(jdo.ToString());
            return r;
        }

        public AuditLog2 Get2(string messageid, string contenttype)
        {
            string url = Constant.PIQUrl;
            AuditLog2 r = new AuditLog2(messageid, url, contenttype);
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog2)JsonConvert.DeserializeObject<AuditLog2>(jdo.ToString());
            return r;
        }
    }

    public class PIPServerAuditLog : IAuditLog
    {
        public AuditLog Get()
        {
            AuditLog r = new AuditLog();
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog)JsonConvert.DeserializeObject<AuditLog>(jdo.ToString());
            return r;
        }

        public AuditLog Get(string messageid, string contenttype)
        {
            string url = Constant.PIPUrl;
            AuditLog r = new AuditLog(messageid, url, contenttype);
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog)JsonConvert.DeserializeObject<AuditLog>(jdo.ToString());
            return r;
        }

        public AuditLog2 Get2()
        {
            AuditLog2 r = new AuditLog2();
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog2)JsonConvert.DeserializeObject<AuditLog2>(jdo.ToString());
            return r;
        }

        public AuditLog2 Get2(string messageid, string contenttype)
        {
            string url = Constant.PIPUrl;
            AuditLog2 r = new AuditLog2(messageid, url, contenttype);
            string response = r.Get();
            var jdo = JsonConvert.DeserializeObject(response);
            r = (AuditLog2)JsonConvert.DeserializeObject<AuditLog2>(jdo.ToString());
            return r;
        }
    }

    public class PIDServerMTDBCollection : IMTDBCollection
    {
        private string config = Constant.PIDConnStr;
        private MTDBCollection mtdbcollection;
        public IEnumerable<VMTDB> Get(MT_DB mtdb)
        {
            mtdbcollection = new MTDBCollection(config);
            mtdbcollection.Get(mtdb);
            return mtdbcollection.MTDBList;
        }

        public string GetSqlString()
        {
            return mtdbcollection.GetSqlString();
        }
    }

    public class PIQServerMTDBCollection : IMTDBCollection
    {
        private string config = Constant.PIQConnStr;
        private MTDBCollection mtdbcollection;
        public IEnumerable<VMTDB> Get(MT_DB mtdb)
        {
            mtdbcollection = new MTDBCollection(config);
            mtdbcollection.Get(mtdb);
            return mtdbcollection.MTDBList;
        }

        public string GetSqlString()
        {
            return mtdbcollection.GetSqlString();
        }
    }

    public class PIPServerMTDBCollection : IMTDBCollection
    {
        private string config = Constant.PIPConnStr;
        private MTDBCollection mtdbcollection;
        public IEnumerable<VMTDB> Get(MT_DB mtdb)
        {
            mtdbcollection = new MTDBCollection(config);
            mtdbcollection.Get(mtdb);
            return mtdbcollection.MTDBList;
        }

        public string GetSqlString()
        {
            return mtdbcollection.GetSqlString();
        }
    }

    public class PIDServerLOOKUPDBCollection : ILOOKUPDBCollection
    {
        private string config = Constant.PIDConnStr;
        private LOOKUPDBCollection lookupdbcollection;
        public IEnumerable<LOOKUP_DB> Get(LOOKUP_DB db)
        {
            lookupdbcollection = new LOOKUPDBCollection(config);
            lookupdbcollection.Get(db);
            return lookupdbcollection.LOOKUPDBList;
        }
    }

    public class PIQServerLOOKUPDBCollection : ILOOKUPDBCollection
    {
        private string config = Constant.PIQConnStr;
        private LOOKUPDBCollection lookupdbcollection;
        public IEnumerable<LOOKUP_DB> Get(LOOKUP_DB db)
        {
            lookupdbcollection = new LOOKUPDBCollection(config);
            lookupdbcollection.Get(db);
            return lookupdbcollection.LOOKUPDBList;
        }
    }

    public class PIPServerLOOKUPDBCollection : ILOOKUPDBCollection
    {
        private string config = Constant.PIPConnStr;
        private LOOKUPDBCollection lookupdbcollection;
        public IEnumerable<LOOKUP_DB> Get(LOOKUP_DB db)
        {
            lookupdbcollection = new LOOKUPDBCollection(config);
            lookupdbcollection.Get(db);
            return lookupdbcollection.LOOKUPDBList;
        }
    }

    public class PIQServerPROCESSDBCollection : IPROCESSDBCollection
    {
        private string config = Constant.PIQConnStr;
        private PROCESSDBCollection dbcollection;
        public IEnumerable<vProcessDB> Get(PROCESS_DB db)
        {
            dbcollection = new PROCESSDBCollection(config);
            dbcollection.Get(db);
            return dbcollection.PROCESSDBList;
        }

        public IEnumerable<vProcessDB> Get(string msgid)
        {
            PROCESS_DB db = new PROCESS_DB();
            db.MSGID = msgid;
            dbcollection = new PROCESSDBCollection(config);
            dbcollection.Get(db);
            return dbcollection.PROCESSDBList;
        }
    }

    public class PIDServerPROCESSDBCollection : IPROCESSDBCollection
    {
        private string config = Constant.PIDConnStr;
        private PROCESSDBCollection dbcollection;
        public IEnumerable<vProcessDB> Get(PROCESS_DB db)
        {
            dbcollection = new PROCESSDBCollection(config);
            dbcollection.Get(db);
            return dbcollection.PROCESSDBList;
        }

        public IEnumerable<vProcessDB> Get(string msgid)
        {
            PROCESS_DB db = new PROCESS_DB();
            db.MSGID = msgid;
            dbcollection = new PROCESSDBCollection(config);
            dbcollection.Get(db);
            return dbcollection.PROCESSDBList;
        }
    }

    public class PIPServerPROCESSDBCollection : IPROCESSDBCollection
    {
        private string config = Constant.PIPConnStr;
        private PROCESSDBCollection dbcollection;
        public IEnumerable<vProcessDB> Get(PROCESS_DB db)
        {
            dbcollection = new PROCESSDBCollection(config);
            dbcollection.Get(db);
            return dbcollection.PROCESSDBList;
        }

        public IEnumerable<vProcessDB> Get(string msgid)
        {
            PROCESS_DB db = new PROCESS_DB();
            db.MSGID = msgid;
            dbcollection = new PROCESSDBCollection(config);
            dbcollection.Get(db);
            return dbcollection.PROCESSDBList;
        }
    }
}