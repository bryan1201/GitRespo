﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using B2BSite.Models;
using System.Web.Script.Serialization;

namespace B2BSite.Controllers
{
    public class StatisticController : Controller
    {
        // GET: Statistic
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MonitorDB(string piServer, DateTime? cdtFrom, DateTime? cdtEnd)
        {
            piServer = string.IsNullOrEmpty(piServer) ? Constant.PIPServer : piServer;
            ViewBag.piServer = piServer;
            MonitorDB db = new Models.MonitorDB(piServer);
            LogDBStatus(piServer);
            return View(db);
        }

        public ActionResult MonitorDBApi(string piServer, DateTime? cdtFrom, DateTime? cdtEnd)
        {
            piServer = string.IsNullOrEmpty(piServer) ? Constant.PIPServer : piServer;
            ViewBag.piServer = piServer;
            MonitorDB db = new Models.MonitorDB(piServer);
            
            return Json(db, JsonRequestBehavior.AllowGet);
        }

        public string MonitorDBApiString(string piServer, DateTime? cdtFrom, DateTime? cdtEnd)
        {
            piServer = string.IsNullOrEmpty(piServer) ? Constant.PIPServer : piServer;
            ViewBag.piServer = piServer;
            MonitorDB db = new Models.MonitorDB(piServer);
            JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
            string json = jsonSerializer.Serialize(db);

            return json;
        }

        public void LogDBStatus(string piServer)
        {
            piServer = string.IsNullOrEmpty(piServer) ? Constant.PIPServer : piServer;
            IStatistic st = DataAccess.CreateStatistic(piServer);
            st.LogSessionDB();
            st.LogProcessDB();
        }
    }
}