﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Oracle.DataAccess;
using Oracle.DataAccess.Types;
using Oracle.DataAccess.Client;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Text;
using System.Reflection;

namespace B2BSite.Models
{
    public class MonitorDB
    {
        public IEnumerable<DBSession> CurrentSession { get; set; }
        public IEnumerable<DBProcess> CurrentProcess { get; set; }
        public IEnumerable<DBParameter> CurrentParameter { get; set; }
        public DBSession TotalSession { get; set; }
        public DBProcess TotalProcess { get; set; }
        public decimal ParameterSessionValue { get; set; }
        public decimal ParameterProcessValue { get; set; }

        public MonitorDB(string server)
        {
            IStatistic st = DataAccess.CreateStatistic(server);
            CurrentParameter = st.GetParameter();
            ParameterSessionValue = st.GetParameterSession();
            ParameterProcessValue = st.GetParameterProcess();
            CurrentSession = st.StatisticSession();
            CurrentProcess = st.StatisticProcess();
            TotalSession = st.TotalStatisticSession();
            TotalProcess = st.TotalStatisticProcess();
        }
    }

    public class Statistic
    {
        private string config = string.Empty;
        public IEnumerable<DBSession> CurrentSession;
        public IEnumerable<DBProcess> CurrentProcess;
        public IEnumerable<DBParameter> CurrentParameter;
        public DBSession TotalSession;
        public DBProcess TotalProcess;
        public decimal ParameterSessionValue;
        public decimal ParameterProcessValue;

        public Statistic(string config) {
            this.config = config;
            CurrentParameter = GetParameter();
            CurrentSession = StatisticSession();
            CurrentProcess = StatisticProcess();
            TotalSession = TotalStatisticSession();
            TotalProcess = TotalStatisticProcess();
        }

        public DBSession TotalStatisticSession()
        {
            TotalSession = CurrentSession.GroupBy(x => new { x.Type }).Select(g =>
                    new DBSession()
                    {
                        Id = g.FirstOrDefault().Id,
                        Type = g.Key.Type,
                        Name = "@Total",
                        NameValue = g.Sum(y => y.NameValue),
                        Percent = (100*g.Sum(y => y.NameValue)/ ParameterSessionValue),
                        Cdt = DateTime.Now
                    }
                ).FirstOrDefault();

            return TotalSession;
        }

        public DBProcess TotalStatisticProcess()
        {
            TotalProcess = CurrentProcess.GroupBy(x => new { x.Type }).Select(g =>
                    new DBProcess()
                    {
                        Id = g.FirstOrDefault().Id,
                        Type = g.Key.Type,
                        Name = "@Total",
                        NameValue = g.Sum(y => y.NameValue),
                        Percent = (100 * g.Sum(y => y.NameValue) / ParameterProcessValue),
                        Cdt = DateTime.Now
                    }
                ).FirstOrDefault();

            return TotalProcess;
        }

        public void LogSessionDB()
        {
            foreach (var item in CurrentSession)
            {
                StringBuilder sb = new StringBuilder();
                string value = string.Empty;
                string sqlvalue = string.Empty;
                string sqlString = "INSERT INTO MONITOR_DB(EVENTID, TYPE, NAME, NAMEVALUE, PERCENT, DATETIME) ";
                sb.Append(sqlString);
                sb.Append("VALUES(");
                value = item.Id.ToString();
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Type;
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Name;
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.NameValue.ToString();
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Percent.ToString();
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Cdt.ToString("yyyy/MM/dd HH:mm:ss");
                sqlvalue = "TO_DATE('@', 'yyyy/MM/dd HH24:MI:SS') "; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                sb.Append(")");

                sqlString = sb.ToString();
                DAO.oracleCmdSP(this.config, sqlString);
            }
        }

        public void LogProcessDB()
        {
            foreach (var item in CurrentProcess)
            {
                StringBuilder sb = new StringBuilder();
                string value = string.Empty;
                string sqlvalue = string.Empty;
                string sqlString = "INSERT INTO MONITOR_DB(EVENTID, TYPE, NAME, NAMEVALUE, PERCENT, DATETIME) ";
                sb.Append(sqlString);
                sb.Append("VALUES(");
                value = item.Id.ToString();
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Type;
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Name;
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.NameValue.ToString();
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Percent.ToString();
                sqlvalue = "'@',"; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                value = item.Cdt.ToString("yyyy/MM/dd HH:mm:ss");
                sqlvalue = "TO_DATE('@', 'yyyy/MM/dd HH24:MI:SS') "; sqlvalue = sqlvalue.Replace("@", value);
                sb.Append(sqlvalue);

                sb.Append(")");

                sqlString = sb.ToString();
                DAO.oracleCmdSP(this.config, sqlString);
            }
        }

        public IEnumerable<DBSession> StatisticSession()
        {
            string sqlString = "SELECT 'SESSION' AS \"TYPE\", USERNAME AS \"NAME\", count(1) AS Cnt FROM v$session GROUP BY 'SESSION', USERNAME";
            System.Data.DataTable dt = DAO.oracleCmdDataSetSP(this.config, sqlString).Tables[0];
            IEnumerable<DBSession> dresult = ConvertToSessionReadings(dt);
            return dresult;
        }

        public IEnumerable<DBProcess> StatisticProcess()
        {
            string sqlString = "SELECT 'PROCESS' AS \"TYPE\", USERNAME AS \"NAME\", count(1) AS Cnt FROM v$process GROUP BY 'PROCESS', USERNAME";
            System.Data.DataTable dt = DAO.oracleCmdDataSetSP(this.config, sqlString).Tables[0];
            IEnumerable<DBProcess> dresult = ConvertToProcessReadings(dt);
            return dresult;
        }

        public IEnumerable<DBParameter> GetParameter()
        {
            string sqlString = "SELECT name, value FROM v$parameter WHERE name IN ('sessions','processes')";
            System.Data.DataTable dt = DAO.oracleCmdDataSetSP(this.config, sqlString).Tables[0];
            IEnumerable<DBParameter> dp = ConvertToParameterReadings(dt);
            ParameterSessionValue = Convert.ToDecimal(dp.Where(x => x.Name == "sessions").Select(x => x.value).FirstOrDefault().ToString());
            ParameterProcessValue = Convert.ToDecimal(dp.Where(x => x.Name == "processes").Select(x => x.value).FirstOrDefault().ToString());
            return dp;
        }

        public decimal GetParameterSession()
        {
            return ParameterSessionValue;
        }

        public decimal GetParameterProcess()
        {
            return ParameterProcessValue;
        }

        private IEnumerable<DBParameter> ConvertToParameterReadings(DataTable dataTable)
        {
            foreach (DataRow row in dataTable.Rows)
            {
                yield return new DBParameter
                {
                    Name = Convert.ToString(row["Name"]),
                    value = Convert.ToString(row["value"])
                };
            }
        }

        private IEnumerable<DBSession> ConvertToSessionReadings(DataTable dataTable)
        {
            foreach (DataRow row in dataTable.Rows)
            {
                yield return new DBSession
                {
                    Id = System.Guid.NewGuid(),
                    Type = Convert.ToString(row[0]),
                    Name = Convert.ToString(row[1]),
                    NameValue = Convert.ToDecimal(row[2].ToString()),
                    Percent = 100* Convert.ToDecimal(row[2].ToString())/ParameterSessionValue,
                    Cdt = DateTime.Now
                };
            }
        }

        private IEnumerable<DBProcess> ConvertToProcessReadings(DataTable dataTable)
        {
            foreach (DataRow row in dataTable.Rows)
            {
                yield return new DBProcess
                {
                    Id = System.Guid.NewGuid(),
                    Type = Convert.ToString(row[0]),
                    Name = Convert.ToString(row[1]),
                    NameValue = Convert.ToDecimal(row[2].ToString()),
                    Percent = 100 * Convert.ToDecimal(row[2].ToString()) / ParameterProcessValue,
                    Cdt = DateTime.Now
                };
            }
        }

    }

    public class DBParameter
    {
        [Key]
        public string Name { get; set; }
        public string value { get; set; }
    }

    public class DBSession
    {
        [Key]
        public Guid Id { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public decimal NameValue { get; set; }
        public decimal Percent { get; set; }
        public DateTime Cdt { get; set; }
    }

    public class DBProcess
    {
        [Key]
        public Guid Id { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public decimal NameValue { get; set; }
        public decimal Percent { get; set; }
        public DateTime Cdt { get; set; }
    }
}